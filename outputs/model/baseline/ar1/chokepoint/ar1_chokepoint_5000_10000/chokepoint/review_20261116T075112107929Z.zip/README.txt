For rank-two see rank_two_curves_README.txt.
For rank-one: factor_response_contrasts.csv: paired posterior comparisons of expected bounded responses at factor 0 vs 1; intervals are equal-tailed 95% credible intervals for the difference, not predictive intervals.
Existing posterior only: no refitting.
Predictive checks are conditional and in-sample, not out-of-sample validation.
Terminal role groups use LAGGED role; chokepoints use the full sample.
Factor associations use posterior mean scores informed by these same responses; they are descriptive, not independent validation or causal effects.
Curve bands are equal-tailed 95% parameter uncertainty, not predictive intervals.
Curves span the minimum-to-maximum range of observation-specific posterior mean latent scores.
Node/month scores are conditional on consecutive activity (and available age for terminals); interpret alongside sampling diagnostics and model limitations.
